cmsearch -E 0.05 -A MSA/MIR156 cmbuild_cmcalibrate/MIR156.cm genome
cmsearch -E 0.05 -A MSA/MIR157 cmbuild_cmcalibrate/MIR157.cm genome
cmsearch -E 0.05 -A MSA/MIR158 cmbuild_cmcalibrate/MIR158.cm genome
cmsearch -E 0.05 -A MSA/MIR159 cmbuild_cmcalibrate/MIR159.cm genome
cmsearch -E 0.05 -A MSA/MIR160 cmbuild_cmcalibrate/MIR160.cm genome
cmsearch -E 0.05 -A MSA/MIR161 cmbuild_cmcalibrate/MIR161.cm genome
cmsearch -E 0.05 -A MSA/MIR162 cmbuild_cmcalibrate/MIR162.cm genome
cmsearch -E 0.05 -A MSA/MIR164 cmbuild_cmcalibrate/MIR164.cm genome
cmsearch -E 0.05 -A MSA/MIR165 cmbuild_cmcalibrate/MIR165.cm genome
cmsearch -E 0.05 -A MSA/MIR166 cmbuild_cmcalibrate/MIR166.cm genome
cmsearch -E 0.05 -A MSA/MIR167 cmbuild_cmcalibrate/MIR167.cm genome
cmsearch -E 0.05 -A MSA/MIR168 cmbuild_cmcalibrate/MIR168.cm genome
cmsearch -E 0.05 -A MSA/MIR169 cmbuild_cmcalibrate/MIR169.cm genome
cmsearch -E 0.05 -A MSA/MIR171 cmbuild_cmcalibrate/MIR171.cm genome
cmsearch -E 0.05 -A MSA/MIR172 cmbuild_cmcalibrate/MIR172.cm genome
cmsearch -E 0.05 -A MSA/MIR173 cmbuild_cmcalibrate/MIR173.cm genome
cmsearch -E 0.05 -A MSA/MIR319 cmbuild_cmcalibrate/MIR319.cm genome
cmsearch -E 0.05 -A MSA/MIR390 cmbuild_cmcalibrate/MIR390.cm genome
cmsearch -E 0.05 -A MSA/MIR391 cmbuild_cmcalibrate/MIR391.cm genome
cmsearch -E 0.05 -A MSA/MIR393 cmbuild_cmcalibrate/MIR393.cm genome
cmsearch -E 0.05 -A MSA/MIR394 cmbuild_cmcalibrate/MIR394.cm genome
cmsearch -E 0.05 -A MSA/MIR395 cmbuild_cmcalibrate/MIR395.cm genome
cmsearch -E 0.05 -A MSA/MIR396 cmbuild_cmcalibrate/MIR396.cm genome
cmsearch -E 0.05 -A MSA/MIR397 cmbuild_cmcalibrate/MIR397.cm genome
cmsearch -E 0.05 -A MSA/MIR398 cmbuild_cmcalibrate/MIR398.cm genome
cmsearch -E 0.05 -A MSA/MIR399 cmbuild_cmcalibrate/MIR399.cm genome
cmsearch -E 0.05 -A MSA/MIR400 cmbuild_cmcalibrate/MIR400.cm genome
cmsearch -E 0.05 -A MSA/MIR403 cmbuild_cmcalibrate/MIR403.cm genome
cmsearch -E 0.05 -A MSA/MIR408 cmbuild_cmcalibrate/MIR408.cm genome
cmsearch -E 0.05 -A MSA/MIR437 cmbuild_cmcalibrate/MIR437.cm genome
cmsearch -E 0.05 -A MSA/MIR439 cmbuild_cmcalibrate/MIR439.cm genome
cmsearch -E 0.05 -A MSA/MIR444 cmbuild_cmcalibrate/MIR444.cm genome
cmsearch -E 0.05 -A MSA/MIR472 cmbuild_cmcalibrate/MIR472.cm genome
cmsearch -E 0.05 -A MSA/MIR475 cmbuild_cmcalibrate/MIR475.cm genome
cmsearch -E 0.05 -A MSA/MIR477 cmbuild_cmcalibrate/MIR477.cm genome
cmsearch -E 0.05 -A MSA/MIR478 cmbuild_cmcalibrate/MIR478.cm genome
cmsearch -E 0.05 -A MSA/MIR479 cmbuild_cmcalibrate/MIR479.cm genome
cmsearch -E 0.05 -A MSA/MIR481 cmbuild_cmcalibrate/MIR481.cm genome
cmsearch -E 0.05 -A MSA/MIR482 cmbuild_cmcalibrate/MIR482.cm genome
cmsearch -E 0.05 -A MSA/MIR528 cmbuild_cmcalibrate/MIR528.cm genome
cmsearch -E 0.05 -A MSA/MIR529 cmbuild_cmcalibrate/MIR529.cm genome
cmsearch -E 0.05 -A MSA/MIR530 cmbuild_cmcalibrate/MIR530.cm genome
cmsearch -E 0.05 -A MSA/MIR531 cmbuild_cmcalibrate/MIR531.cm genome
cmsearch -E 0.05 -A MSA/MIR533 cmbuild_cmcalibrate/MIR533.cm genome
cmsearch -E 0.05 -A MSA/MIR535 cmbuild_cmcalibrate/MIR535.cm genome
cmsearch -E 0.05 -A MSA/MIR536 cmbuild_cmcalibrate/MIR536.cm genome
cmsearch -E 0.05 -A MSA/MIR537 cmbuild_cmcalibrate/MIR537.cm genome
cmsearch -E 0.05 -A MSA/MIR774 cmbuild_cmcalibrate/MIR774.cm genome
cmsearch -E 0.05 -A MSA/MIR812 cmbuild_cmcalibrate/MIR812.cm genome
cmsearch -E 0.05 -A MSA/MIR818 cmbuild_cmcalibrate/MIR818.cm genome
cmsearch -E 0.05 -A MSA/MIR821 cmbuild_cmcalibrate/MIR821.cm genome
cmsearch -E 0.05 -A MSA/MIR824 cmbuild_cmcalibrate/MIR824.cm genome
cmsearch -E 0.05 -A MSA/MIR827 cmbuild_cmcalibrate/MIR827.cm genome
cmsearch -E 0.05 -A MSA/MIR828 cmbuild_cmcalibrate/MIR828.cm genome
cmsearch -E 0.05 -A MSA/MIR845 cmbuild_cmcalibrate/MIR845.cm genome
cmsearch -E 0.05 -A MSA/MIR854 cmbuild_cmcalibrate/MIR854.cm genome
cmsearch -E 0.05 -A MSA/MIR857 cmbuild_cmcalibrate/MIR857.cm genome
cmsearch -E 0.05 -A MSA/MIR858 cmbuild_cmcalibrate/MIR858.cm genome
cmsearch -E 0.05 -A MSA/MIR860 cmbuild_cmcalibrate/MIR860.cm genome
cmsearch -E 0.05 -A MSA/MIR862 cmbuild_cmcalibrate/MIR862.cm genome
cmsearch -E 0.05 -A MSA/MIR902 cmbuild_cmcalibrate/MIR902.cm genome
cmsearch -E 0.05 -A MSA/MIR946 cmbuild_cmcalibrate/MIR946.cm genome
cmsearch -E 0.05 -A MSA/MIR949 cmbuild_cmcalibrate/MIR949.cm genome
cmsearch -E 0.05 -A MSA/MIR950 cmbuild_cmcalibrate/MIR950.cm genome
cmsearch -E 0.05 -A MSA/MIR952 cmbuild_cmcalibrate/MIR952.cm genome
cmsearch -E 0.05 -A MSA/MIR1023 cmbuild_cmcalibrate/MIR1023.cm genome
cmsearch -E 0.05 -A MSA/MIR1030 cmbuild_cmcalibrate/MIR1030.cm genome
cmsearch -E 0.05 -A MSA/MIR1033 cmbuild_cmcalibrate/MIR1033.cm genome
cmsearch -E 0.05 -A MSA/MIR1063 cmbuild_cmcalibrate/MIR1063.cm genome
cmsearch -E 0.05 -A MSA/MIR1120 cmbuild_cmcalibrate/MIR1120.cm genome
cmsearch -E 0.05 -A MSA/MIR1122 cmbuild_cmcalibrate/MIR1122.cm genome
cmsearch -E 0.05 -A MSA/MIR1219 cmbuild_cmcalibrate/MIR1219.cm genome
cmsearch -E 0.05 -A MSA/MIR1222 cmbuild_cmcalibrate/MIR1222.cm genome
cmsearch -E 0.05 -A MSA/MIR1223 cmbuild_cmcalibrate/MIR1223.cm genome
cmsearch -E 0.05 -A MSA/MIR1311 cmbuild_cmcalibrate/MIR1311.cm genome
cmsearch -E 0.05 -A MSA/MIR1312 cmbuild_cmcalibrate/MIR1312.cm genome
cmsearch -E 0.05 -A MSA/MIR1313 cmbuild_cmcalibrate/MIR1313.cm genome
cmsearch -E 0.05 -A MSA/MIR1428 cmbuild_cmcalibrate/MIR1428.cm genome
cmsearch -E 0.05 -A MSA/MIR1432 cmbuild_cmcalibrate/MIR1432.cm genome
cmsearch -E 0.05 -A MSA/MIR1444 cmbuild_cmcalibrate/MIR1444.cm genome
cmsearch -E 0.05 -A MSA/MIR1446 cmbuild_cmcalibrate/MIR1446.cm genome
cmsearch -E 0.05 -A MSA/MIR1507 cmbuild_cmcalibrate/MIR1507.cm genome
cmsearch -E 0.05 -A MSA/MIR1508 cmbuild_cmcalibrate/MIR1508.cm genome
cmsearch -E 0.05 -A MSA/MIR1509 cmbuild_cmcalibrate/MIR1509.cm genome
cmsearch -E 0.05 -A MSA/MIR1510 cmbuild_cmcalibrate/MIR1510.cm genome
cmsearch -E 0.05 -A MSA/MIR1511 cmbuild_cmcalibrate/MIR1511.cm genome
cmsearch -E 0.05 -A MSA/MIR1515 cmbuild_cmcalibrate/MIR1515.cm genome
cmsearch -E 0.05 -A MSA/MIR1516 cmbuild_cmcalibrate/MIR1516.cm genome
cmsearch -E 0.05 -A MSA/MIR1520 cmbuild_cmcalibrate/MIR1520.cm genome
cmsearch -E 0.05 -A MSA/MIR1846 cmbuild_cmcalibrate/MIR1846.cm genome
cmsearch -E 0.05 -A MSA/MIR1861 cmbuild_cmcalibrate/MIR1861.cm genome
cmsearch -E 0.05 -A MSA/MIR1862 cmbuild_cmcalibrate/MIR1862.cm genome
cmsearch -E 0.05 -A MSA/MIR1863 cmbuild_cmcalibrate/MIR1863.cm genome
cmsearch -E 0.05 -A MSA/MIR1882 cmbuild_cmcalibrate/MIR1882.cm genome
cmsearch -E 0.05 -A MSA/MIR1886 cmbuild_cmcalibrate/MIR1886.cm genome
cmsearch -E 0.05 -A MSA/MIR1919 cmbuild_cmcalibrate/MIR1919.cm genome
cmsearch -E 0.05 -A MSA/MIR2111 cmbuild_cmcalibrate/MIR2111.cm genome
cmsearch -E 0.05 -A MSA/MIR2118 cmbuild_cmcalibrate/MIR2118.cm genome
cmsearch -E 0.05 -A MSA/MIR2275 cmbuild_cmcalibrate/MIR2275.cm genome
cmsearch -E 0.05 -A MSA/MIR2585 cmbuild_cmcalibrate/MIR2585.cm genome
cmsearch -E 0.05 -A MSA/MIR2587 cmbuild_cmcalibrate/MIR2587.cm genome
cmsearch -E 0.05 -A MSA/MIR2590 cmbuild_cmcalibrate/MIR2590.cm genome
cmsearch -E 0.05 -A MSA/MIR2592 cmbuild_cmcalibrate/MIR2592.cm genome
cmsearch -E 0.05 -A MSA/MIR2593 cmbuild_cmcalibrate/MIR2593.cm genome
cmsearch -E 0.05 -A MSA/MIR2600 cmbuild_cmcalibrate/MIR2600.cm genome
cmsearch -E 0.05 -A MSA/MIR2606 cmbuild_cmcalibrate/MIR2606.cm genome
cmsearch -E 0.05 -A MSA/MIR2629 cmbuild_cmcalibrate/MIR2629.cm genome
cmsearch -E 0.05 -A MSA/MIR2630 cmbuild_cmcalibrate/MIR2630.cm genome
cmsearch -E 0.05 -A MSA/MIR2652 cmbuild_cmcalibrate/MIR2652.cm genome
cmsearch -E 0.05 -A MSA/MIR2653 cmbuild_cmcalibrate/MIR2653.cm genome
cmsearch -E 0.05 -A MSA/MIR2655 cmbuild_cmcalibrate/MIR2655.cm genome
cmsearch -E 0.05 -A MSA/MIR2656 cmbuild_cmcalibrate/MIR2656.cm genome
cmsearch -E 0.05 -A MSA/MIR2659 cmbuild_cmcalibrate/MIR2659.cm genome
cmsearch -E 0.05 -A MSA/MIR2670 cmbuild_cmcalibrate/MIR2670.cm genome
cmsearch -E 0.05 -A MSA/MIR2671 cmbuild_cmcalibrate/MIR2671.cm genome
cmsearch -E 0.05 -A MSA/MIR2676 cmbuild_cmcalibrate/MIR2676.cm genome
cmsearch -E 0.05 -A MSA/MIR2680 cmbuild_cmcalibrate/MIR2680.cm genome
cmsearch -E 0.05 -A MSA/MIR2907 cmbuild_cmcalibrate/MIR2907.cm genome
cmsearch -E 0.05 -A MSA/MIR2950 cmbuild_cmcalibrate/MIR2950.cm genome
cmsearch -E 0.05 -A MSA/MIR3454 cmbuild_cmcalibrate/MIR3454.cm genome
cmsearch -E 0.05 -A MSA/MIR3627 cmbuild_cmcalibrate/MIR3627.cm genome
cmsearch -E 0.05 -A MSA/MIR3631 cmbuild_cmcalibrate/MIR3631.cm genome
cmsearch -E 0.05 -A MSA/MIR3693 cmbuild_cmcalibrate/MIR3693.cm genome
cmsearch -E 0.05 -A MSA/MIR3695 cmbuild_cmcalibrate/MIR3695.cm genome
cmsearch -E 0.05 -A MSA/MIR3701 cmbuild_cmcalibrate/MIR3701.cm genome
cmsearch -E 0.05 -A MSA/MIR3710 cmbuild_cmcalibrate/MIR3710.cm genome
cmsearch -E 0.05 -A MSA/MIR4348 cmbuild_cmcalibrate/MIR4348.cm genome
cmsearch -E 0.05 -A MSA/MIR4387 cmbuild_cmcalibrate/MIR4387.cm genome
cmsearch -E 0.05 -A MSA/MIR4414 cmbuild_cmcalibrate/MIR4414.cm genome
cmsearch -E 0.05 -A MSA/MIR5037 cmbuild_cmcalibrate/MIR5037.cm genome
cmsearch -E 0.05 -A MSA/MIR5049 cmbuild_cmcalibrate/MIR5049.cm genome
cmsearch -E 0.05 -A MSA/MIR5062 cmbuild_cmcalibrate/MIR5062.cm genome
cmsearch -E 0.05 -A MSA/MIR5139 cmbuild_cmcalibrate/MIR5139.cm genome
cmsearch -E 0.05 -A MSA/MIR5174 cmbuild_cmcalibrate/MIR5174.cm genome
cmsearch -E 0.05 -A MSA/MIR5181 cmbuild_cmcalibrate/MIR5181.cm genome
cmsearch -E 0.05 -A MSA/MIR5185 cmbuild_cmcalibrate/MIR5185.cm genome
cmsearch -E 0.05 -A MSA/MIR5200 cmbuild_cmcalibrate/MIR5200.cm genome
cmsearch -E 0.05 -A MSA/MIR5205 cmbuild_cmcalibrate/MIR5205.cm genome
cmsearch -E 0.05 -A MSA/MIR5208 cmbuild_cmcalibrate/MIR5208.cm genome
cmsearch -E 0.05 -A MSA/MIR5225 cmbuild_cmcalibrate/MIR5225.cm genome
cmsearch -E 0.05 -A MSA/MIR5236 cmbuild_cmcalibrate/MIR5236.cm genome
cmsearch -E 0.05 -A MSA/MIR5267 cmbuild_cmcalibrate/MIR5267.cm genome
cmsearch -E 0.05 -A MSA/MIR5271 cmbuild_cmcalibrate/MIR5271.cm genome
cmsearch -E 0.05 -A MSA/MIR5272 cmbuild_cmcalibrate/MIR5272.cm genome
cmsearch -E 0.05 -A MSA/MIR5281 cmbuild_cmcalibrate/MIR5281.cm genome
cmsearch -E 0.05 -A MSA/MIR5284 cmbuild_cmcalibrate/MIR5284.cm genome
cmsearch -E 0.05 -A MSA/MIR5287 cmbuild_cmcalibrate/MIR5287.cm genome
cmsearch -E 0.05 -A MSA/MIR5295 cmbuild_cmcalibrate/MIR5295.cm genome
cmsearch -E 0.05 -A MSA/MIR5298 cmbuild_cmcalibrate/MIR5298.cm genome
cmsearch -E 0.05 -A MSA/MIR5303 cmbuild_cmcalibrate/MIR5303.cm genome
cmsearch -E 0.05 -A MSA/MIR5565 cmbuild_cmcalibrate/MIR5565.cm genome
cmsearch -E 0.05 -A MSA/MIR5568 cmbuild_cmcalibrate/MIR5568.cm genome
cmsearch -E 0.05 -A MSA/MIR5635 cmbuild_cmcalibrate/MIR5635.cm genome
cmsearch -E 0.05 -A MSA/MIR5645 cmbuild_cmcalibrate/MIR5645.cm genome
cmsearch -E 0.05 -A MSA/MIR5741 cmbuild_cmcalibrate/MIR5741.cm genome
cmsearch -E 0.05 -A MSA/MIR5780 cmbuild_cmcalibrate/MIR5780.cm genome
cmsearch -E 0.05 -A MSA/MIR6025 cmbuild_cmcalibrate/MIR6025.cm genome
cmsearch -E 0.05 -A MSA/MIR6108 cmbuild_cmcalibrate/MIR6108.cm genome
cmsearch -E 0.05 -A MSA/MIR6135 cmbuild_cmcalibrate/MIR6135.cm genome
cmsearch -E 0.05 -A MSA/MIR6140 cmbuild_cmcalibrate/MIR6140.cm genome
cmsearch -E 0.05 -A MSA/MIR6145 cmbuild_cmcalibrate/MIR6145.cm genome
cmsearch -E 0.05 -A MSA/MIR6151 cmbuild_cmcalibrate/MIR6151.cm genome
cmsearch -E 0.05 -A MSA/MIR6161 cmbuild_cmcalibrate/MIR6161.cm genome
cmsearch -E 0.05 -A MSA/MIR6425 cmbuild_cmcalibrate/MIR6425.cm genome
cmsearch -E 0.05 -A MSA/MIR6440 cmbuild_cmcalibrate/MIR6440.cm genome
cmsearch -E 0.05 -A MSA/MIR6462 cmbuild_cmcalibrate/MIR6462.cm genome
cmsearch -E 0.05 -A MSA/MIR7121 cmbuild_cmcalibrate/MIR7121.cm genome
cmsearch -E 0.05 -A MSA/MIR7122 cmbuild_cmcalibrate/MIR7122.cm genome
cmsearch -E 0.05 -A MSA/MIR7484 cmbuild_cmcalibrate/MIR7484.cm genome
cmsearch -E 0.05 -A MSA/MIR7486 cmbuild_cmcalibrate/MIR7486.cm genome
cmsearch -E 0.05 -A MSA/MIR7492 cmbuild_cmcalibrate/MIR7492.cm genome
cmsearch -E 0.05 -A MSA/MIR7494 cmbuild_cmcalibrate/MIR7494.cm genome
cmsearch -E 0.05 -A MSA/MIR7502 cmbuild_cmcalibrate/MIR7502.cm genome
cmsearch -E 0.05 -A MSA/MIR7504 cmbuild_cmcalibrate/MIR7504.cm genome
cmsearch -E 0.05 -A MSA/MIR7526 cmbuild_cmcalibrate/MIR7526.cm genome
cmsearch -E 0.05 -A MSA/MIR7533 cmbuild_cmcalibrate/MIR7533.cm genome
cmsearch -E 0.05 -A MSA/MIR7696 cmbuild_cmcalibrate/MIR7696.cm genome
cmsearch -E 0.05 -A MSA/MIR7981 cmbuild_cmcalibrate/MIR7981.cm genome
cmsearch -E 0.05 -A MSA/MIR7984 cmbuild_cmcalibrate/MIR7984.cm genome
cmsearch -E 0.05 -A MSA/MIR7993 cmbuild_cmcalibrate/MIR7993.cm genome
cmsearch -E 0.05 -A MSA/MIR8032 cmbuild_cmcalibrate/MIR8032.cm genome
cmsearch -E 0.05 -A MSA/MIR8139 cmbuild_cmcalibrate/MIR8139.cm genome
cmsearch -E 0.05 -A MSA/MIR8167 cmbuild_cmcalibrate/MIR8167.cm genome
cmsearch -E 0.05 -A MSA/MIR8552 cmbuild_cmcalibrate/MIR8552.cm genome
cmsearch -E 0.05 -A MSA/MIR8565 cmbuild_cmcalibrate/MIR8565.cm genome
cmsearch -E 0.05 -A MSA/MIR8623 cmbuild_cmcalibrate/MIR8623.cm genome
cmsearch -E 0.05 -A MSA/MIR8639 cmbuild_cmcalibrate/MIR8639.cm genome
cmsearch -E 0.05 -A MSA/MIR8657 cmbuild_cmcalibrate/MIR8657.cm genome
cmsearch -E 0.05 -A MSA/MIR8743 cmbuild_cmcalibrate/MIR8743.cm genome
cmsearch -E 0.05 -A MSA/MIR8762 cmbuild_cmcalibrate/MIR8762.cm genome
cmsearch -E 0.05 -A MSA/MIR8771 cmbuild_cmcalibrate/MIR8771.cm genome
cmsearch -E 0.05 -A MSA/MIR8776 cmbuild_cmcalibrate/MIR8776.cm genome
cmsearch -E 0.05 -A MSA/MIR8788 cmbuild_cmcalibrate/MIR8788.cm genome
cmsearch -E 0.05 -A MSA/MIR9560 cmbuild_cmcalibrate/MIR9560.cm genome
cmsearch -E 0.05 -A MSA/MIR9674 cmbuild_cmcalibrate/MIR9674.cm genome
cmsearch -E 0.05 -A MSA/MIR9746 cmbuild_cmcalibrate/MIR9746.cm genome
cmsearch -E 0.05 -A MSA/MIR10186 cmbuild_cmcalibrate/MIR10186.cm genome
cmsearch -E 0.05 -A MSA/MIR10193 cmbuild_cmcalibrate/MIR10193.cm genome
cmsearch -E 0.05 -A MSA/MIR10405 cmbuild_cmcalibrate/MIR10405.cm genome
cmsearch -E 0.05 -A MSA/MIR10407 cmbuild_cmcalibrate/MIR10407.cm genome
cmsearch -E 0.05 -A MSA/MIR10424 cmbuild_cmcalibrate/MIR10424.cm genome
cmsearch -E 0.05 -A MSA/MIR10981 cmbuild_cmcalibrate/MIR10981.cm genome
cmsearch -E 0.05 -A MSA/MIR10982 cmbuild_cmcalibrate/MIR10982.cm genome
cmsearch -E 0.05 -A MSA/MIR10989 cmbuild_cmcalibrate/MIR10989.cm genome
cmsearch -E 0.05 -A MSA/MIR10991 cmbuild_cmcalibrate/MIR10991.cm genome
cmsearch -E 0.05 -A MSA/MIR10993 cmbuild_cmcalibrate/MIR10993.cm genome
cmsearch -E 0.05 -A MSA/MIR11068 cmbuild_cmcalibrate/MIR11068.cm genome
cmsearch -E 0.05 -A MSA/MIR11072 cmbuild_cmcalibrate/MIR11072.cm genome
cmsearch -E 0.05 -A MSA/MIR11077 cmbuild_cmcalibrate/MIR11077.cm genome
cmsearch -E 0.05 -A MSA/MIR11078 cmbuild_cmcalibrate/MIR11078.cm genome
cmsearch -E 0.05 -A MSA/MIR11082 cmbuild_cmcalibrate/MIR11082.cm genome
cmsearch -E 0.05 -A MSA/MIR11083 cmbuild_cmcalibrate/MIR11083.cm genome
cmsearch -E 0.05 -A MSA/MIR11090 cmbuild_cmcalibrate/MIR11090.cm genome
cmsearch -E 0.05 -A MSA/MIR11097 cmbuild_cmcalibrate/MIR11097.cm genome
cmsearch -E 0.05 -A MSA/MIR11103 cmbuild_cmcalibrate/MIR11103.cm genome
cmsearch -E 0.05 -A MSA/MIR11105 cmbuild_cmcalibrate/MIR11105.cm genome
cmsearch -E 0.05 -A MSA/MIR11108 cmbuild_cmcalibrate/MIR11108.cm genome
cmsearch -E 0.05 -A MSA/MIR11135 cmbuild_cmcalibrate/MIR11135.cm genome
cmsearch -E 0.05 -A MSA/MIR11145 cmbuild_cmcalibrate/MIR11145.cm genome
cmsearch -E 0.05 -A MSA/MIR11155 cmbuild_cmcalibrate/MIR11155.cm genome
cmsearch -E 0.05 -A MSA/MIR11288 cmbuild_cmcalibrate/MIR11288.cm genome
cmsearch -E 0.05 -A MSA/MIR11409 cmbuild_cmcalibrate/MIR11409.cm genome
cmsearch -E 0.05 -A MSA/MIR11411 cmbuild_cmcalibrate/MIR11411.cm genome
cmsearch -E 0.05 -A MSA/MIR11420 cmbuild_cmcalibrate/MIR11420.cm genome
cmsearch -E 0.05 -A MSA/MIR11423 cmbuild_cmcalibrate/MIR11423.cm genome
cmsearch -E 0.05 -A MSA/MIR11425 cmbuild_cmcalibrate/MIR11425.cm genome
cmsearch -E 0.05 -A MSA/MIR11429 cmbuild_cmcalibrate/MIR11429.cm genome
cmsearch -E 0.05 -A MSA/MIR11436 cmbuild_cmcalibrate/MIR11436.cm genome
cmsearch -E 0.05 -A MSA/MIR11466 cmbuild_cmcalibrate/MIR11466.cm genome
cmsearch -E 0.05 -A MSA/MIR11523 cmbuild_cmcalibrate/MIR11523.cm genome
cmsearch -E 0.05 -A MSA/MIR11546 cmbuild_cmcalibrate/MIR11546.cm genome
extractalign MSA/MIR156 MSA_FASTA/MIR156
extractalign MSA/MIR157 MSA_FASTA/MIR157
extractalign MSA/MIR158 MSA_FASTA/MIR158
extractalign MSA/MIR159 MSA_FASTA/MIR159
extractalign MSA/MIR160 MSA_FASTA/MIR160
extractalign MSA/MIR161 MSA_FASTA/MIR161
extractalign MSA/MIR162 MSA_FASTA/MIR162
extractalign MSA/MIR164 MSA_FASTA/MIR164
extractalign MSA/MIR165 MSA_FASTA/MIR165
extractalign MSA/MIR166 MSA_FASTA/MIR166
extractalign MSA/MIR167 MSA_FASTA/MIR167
extractalign MSA/MIR168 MSA_FASTA/MIR168
extractalign MSA/MIR169 MSA_FASTA/MIR169
extractalign MSA/MIR171 MSA_FASTA/MIR171
extractalign MSA/MIR172 MSA_FASTA/MIR172
extractalign MSA/MIR173 MSA_FASTA/MIR173
extractalign MSA/MIR319 MSA_FASTA/MIR319
extractalign MSA/MIR390 MSA_FASTA/MIR390
extractalign MSA/MIR391 MSA_FASTA/MIR391
extractalign MSA/MIR393 MSA_FASTA/MIR393
extractalign MSA/MIR394 MSA_FASTA/MIR394
extractalign MSA/MIR395 MSA_FASTA/MIR395
extractalign MSA/MIR396 MSA_FASTA/MIR396
extractalign MSA/MIR397 MSA_FASTA/MIR397
extractalign MSA/MIR398 MSA_FASTA/MIR398
extractalign MSA/MIR399 MSA_FASTA/MIR399
extractalign MSA/MIR400 MSA_FASTA/MIR400
extractalign MSA/MIR403 MSA_FASTA/MIR403
extractalign MSA/MIR408 MSA_FASTA/MIR408
extractalign MSA/MIR437 MSA_FASTA/MIR437
extractalign MSA/MIR439 MSA_FASTA/MIR439
extractalign MSA/MIR444 MSA_FASTA/MIR444
extractalign MSA/MIR472 MSA_FASTA/MIR472
extractalign MSA/MIR475 MSA_FASTA/MIR475
extractalign MSA/MIR477 MSA_FASTA/MIR477
extractalign MSA/MIR478 MSA_FASTA/MIR478
extractalign MSA/MIR479 MSA_FASTA/MIR479
extractalign MSA/MIR481 MSA_FASTA/MIR481
extractalign MSA/MIR482 MSA_FASTA/MIR482
extractalign MSA/MIR528 MSA_FASTA/MIR528
extractalign MSA/MIR529 MSA_FASTA/MIR529
extractalign MSA/MIR530 MSA_FASTA/MIR530
extractalign MSA/MIR531 MSA_FASTA/MIR531
extractalign MSA/MIR533 MSA_FASTA/MIR533
extractalign MSA/MIR535 MSA_FASTA/MIR535
extractalign MSA/MIR536 MSA_FASTA/MIR536
extractalign MSA/MIR537 MSA_FASTA/MIR537
extractalign MSA/MIR774 MSA_FASTA/MIR774
extractalign MSA/MIR812 MSA_FASTA/MIR812
extractalign MSA/MIR818 MSA_FASTA/MIR818
extractalign MSA/MIR821 MSA_FASTA/MIR821
extractalign MSA/MIR824 MSA_FASTA/MIR824
extractalign MSA/MIR827 MSA_FASTA/MIR827
extractalign MSA/MIR828 MSA_FASTA/MIR828
extractalign MSA/MIR845 MSA_FASTA/MIR845
extractalign MSA/MIR854 MSA_FASTA/MIR854
extractalign MSA/MIR857 MSA_FASTA/MIR857
extractalign MSA/MIR858 MSA_FASTA/MIR858
extractalign MSA/MIR860 MSA_FASTA/MIR860
extractalign MSA/MIR862 MSA_FASTA/MIR862
extractalign MSA/MIR902 MSA_FASTA/MIR902
extractalign MSA/MIR946 MSA_FASTA/MIR946
extractalign MSA/MIR949 MSA_FASTA/MIR949
extractalign MSA/MIR950 MSA_FASTA/MIR950
extractalign MSA/MIR952 MSA_FASTA/MIR952
extractalign MSA/MIR1023 MSA_FASTA/MIR1023
extractalign MSA/MIR1030 MSA_FASTA/MIR1030
extractalign MSA/MIR1033 MSA_FASTA/MIR1033
extractalign MSA/MIR1063 MSA_FASTA/MIR1063
extractalign MSA/MIR1120 MSA_FASTA/MIR1120
extractalign MSA/MIR1122 MSA_FASTA/MIR1122
extractalign MSA/MIR1219 MSA_FASTA/MIR1219
extractalign MSA/MIR1222 MSA_FASTA/MIR1222
extractalign MSA/MIR1223 MSA_FASTA/MIR1223
extractalign MSA/MIR1311 MSA_FASTA/MIR1311
extractalign MSA/MIR1312 MSA_FASTA/MIR1312
extractalign MSA/MIR1313 MSA_FASTA/MIR1313
extractalign MSA/MIR1428 MSA_FASTA/MIR1428
extractalign MSA/MIR1432 MSA_FASTA/MIR1432
extractalign MSA/MIR1444 MSA_FASTA/MIR1444
extractalign MSA/MIR1446 MSA_FASTA/MIR1446
extractalign MSA/MIR1507 MSA_FASTA/MIR1507
extractalign MSA/MIR1508 MSA_FASTA/MIR1508
extractalign MSA/MIR1509 MSA_FASTA/MIR1509
extractalign MSA/MIR1510 MSA_FASTA/MIR1510
extractalign MSA/MIR1511 MSA_FASTA/MIR1511
extractalign MSA/MIR1515 MSA_FASTA/MIR1515
extractalign MSA/MIR1516 MSA_FASTA/MIR1516
extractalign MSA/MIR1520 MSA_FASTA/MIR1520
extractalign MSA/MIR1846 MSA_FASTA/MIR1846
extractalign MSA/MIR1861 MSA_FASTA/MIR1861
extractalign MSA/MIR1862 MSA_FASTA/MIR1862
extractalign MSA/MIR1863 MSA_FASTA/MIR1863
extractalign MSA/MIR1882 MSA_FASTA/MIR1882
extractalign MSA/MIR1886 MSA_FASTA/MIR1886
extractalign MSA/MIR1919 MSA_FASTA/MIR1919
extractalign MSA/MIR2111 MSA_FASTA/MIR2111
extractalign MSA/MIR2118 MSA_FASTA/MIR2118
extractalign MSA/MIR2275 MSA_FASTA/MIR2275
extractalign MSA/MIR2585 MSA_FASTA/MIR2585
extractalign MSA/MIR2587 MSA_FASTA/MIR2587
extractalign MSA/MIR2590 MSA_FASTA/MIR2590
extractalign MSA/MIR2592 MSA_FASTA/MIR2592
extractalign MSA/MIR2593 MSA_FASTA/MIR2593
extractalign MSA/MIR2600 MSA_FASTA/MIR2600
extractalign MSA/MIR2606 MSA_FASTA/MIR2606
extractalign MSA/MIR2629 MSA_FASTA/MIR2629
extractalign MSA/MIR2630 MSA_FASTA/MIR2630
extractalign MSA/MIR2652 MSA_FASTA/MIR2652
extractalign MSA/MIR2653 MSA_FASTA/MIR2653
extractalign MSA/MIR2655 MSA_FASTA/MIR2655
extractalign MSA/MIR2656 MSA_FASTA/MIR2656
extractalign MSA/MIR2659 MSA_FASTA/MIR2659
extractalign MSA/MIR2670 MSA_FASTA/MIR2670
extractalign MSA/MIR2671 MSA_FASTA/MIR2671
extractalign MSA/MIR2676 MSA_FASTA/MIR2676
extractalign MSA/MIR2680 MSA_FASTA/MIR2680
extractalign MSA/MIR2907 MSA_FASTA/MIR2907
extractalign MSA/MIR2950 MSA_FASTA/MIR2950
extractalign MSA/MIR3454 MSA_FASTA/MIR3454
extractalign MSA/MIR3627 MSA_FASTA/MIR3627
extractalign MSA/MIR3631 MSA_FASTA/MIR3631
extractalign MSA/MIR3693 MSA_FASTA/MIR3693
extractalign MSA/MIR3695 MSA_FASTA/MIR3695
extractalign MSA/MIR3701 MSA_FASTA/MIR3701
extractalign MSA/MIR3710 MSA_FASTA/MIR3710
extractalign MSA/MIR4348 MSA_FASTA/MIR4348
extractalign MSA/MIR4387 MSA_FASTA/MIR4387
extractalign MSA/MIR4414 MSA_FASTA/MIR4414
extractalign MSA/MIR5037 MSA_FASTA/MIR5037
extractalign MSA/MIR5049 MSA_FASTA/MIR5049
extractalign MSA/MIR5062 MSA_FASTA/MIR5062
extractalign MSA/MIR5139 MSA_FASTA/MIR5139
extractalign MSA/MIR5174 MSA_FASTA/MIR5174
extractalign MSA/MIR5181 MSA_FASTA/MIR5181
extractalign MSA/MIR5185 MSA_FASTA/MIR5185
extractalign MSA/MIR5200 MSA_FASTA/MIR5200
extractalign MSA/MIR5205 MSA_FASTA/MIR5205
extractalign MSA/MIR5208 MSA_FASTA/MIR5208
extractalign MSA/MIR5225 MSA_FASTA/MIR5225
extractalign MSA/MIR5236 MSA_FASTA/MIR5236
extractalign MSA/MIR5267 MSA_FASTA/MIR5267
extractalign MSA/MIR5271 MSA_FASTA/MIR5271
extractalign MSA/MIR5272 MSA_FASTA/MIR5272
extractalign MSA/MIR5281 MSA_FASTA/MIR5281
extractalign MSA/MIR5284 MSA_FASTA/MIR5284
extractalign MSA/MIR5287 MSA_FASTA/MIR5287
extractalign MSA/MIR5295 MSA_FASTA/MIR5295
extractalign MSA/MIR5298 MSA_FASTA/MIR5298
extractalign MSA/MIR5303 MSA_FASTA/MIR5303
extractalign MSA/MIR5565 MSA_FASTA/MIR5565
extractalign MSA/MIR5568 MSA_FASTA/MIR5568
extractalign MSA/MIR5635 MSA_FASTA/MIR5635
extractalign MSA/MIR5645 MSA_FASTA/MIR5645
extractalign MSA/MIR5741 MSA_FASTA/MIR5741
extractalign MSA/MIR5780 MSA_FASTA/MIR5780
extractalign MSA/MIR6025 MSA_FASTA/MIR6025
extractalign MSA/MIR6108 MSA_FASTA/MIR6108
extractalign MSA/MIR6135 MSA_FASTA/MIR6135
extractalign MSA/MIR6140 MSA_FASTA/MIR6140
extractalign MSA/MIR6145 MSA_FASTA/MIR6145
extractalign MSA/MIR6151 MSA_FASTA/MIR6151
extractalign MSA/MIR6161 MSA_FASTA/MIR6161
extractalign MSA/MIR6425 MSA_FASTA/MIR6425
extractalign MSA/MIR6440 MSA_FASTA/MIR6440
extractalign MSA/MIR6462 MSA_FASTA/MIR6462
extractalign MSA/MIR7121 MSA_FASTA/MIR7121
extractalign MSA/MIR7122 MSA_FASTA/MIR7122
extractalign MSA/MIR7484 MSA_FASTA/MIR7484
extractalign MSA/MIR7486 MSA_FASTA/MIR7486
extractalign MSA/MIR7492 MSA_FASTA/MIR7492
extractalign MSA/MIR7494 MSA_FASTA/MIR7494
extractalign MSA/MIR7502 MSA_FASTA/MIR7502
extractalign MSA/MIR7504 MSA_FASTA/MIR7504
extractalign MSA/MIR7526 MSA_FASTA/MIR7526
extractalign MSA/MIR7533 MSA_FASTA/MIR7533
extractalign MSA/MIR7696 MSA_FASTA/MIR7696
extractalign MSA/MIR7981 MSA_FASTA/MIR7981
extractalign MSA/MIR7984 MSA_FASTA/MIR7984
extractalign MSA/MIR7993 MSA_FASTA/MIR7993
extractalign MSA/MIR8032 MSA_FASTA/MIR8032
extractalign MSA/MIR8139 MSA_FASTA/MIR8139
extractalign MSA/MIR8167 MSA_FASTA/MIR8167
extractalign MSA/MIR8552 MSA_FASTA/MIR8552
extractalign MSA/MIR8565 MSA_FASTA/MIR8565
extractalign MSA/MIR8623 MSA_FASTA/MIR8623
extractalign MSA/MIR8639 MSA_FASTA/MIR8639
extractalign MSA/MIR8657 MSA_FASTA/MIR8657
extractalign MSA/MIR8743 MSA_FASTA/MIR8743
extractalign MSA/MIR8762 MSA_FASTA/MIR8762
extractalign MSA/MIR8771 MSA_FASTA/MIR8771
extractalign MSA/MIR8776 MSA_FASTA/MIR8776
extractalign MSA/MIR8788 MSA_FASTA/MIR8788
extractalign MSA/MIR9560 MSA_FASTA/MIR9560
extractalign MSA/MIR9674 MSA_FASTA/MIR9674
extractalign MSA/MIR9746 MSA_FASTA/MIR9746
extractalign MSA/MIR10186 MSA_FASTA/MIR10186
extractalign MSA/MIR10193 MSA_FASTA/MIR10193
extractalign MSA/MIR10405 MSA_FASTA/MIR10405
extractalign MSA/MIR10407 MSA_FASTA/MIR10407
extractalign MSA/MIR10424 MSA_FASTA/MIR10424
extractalign MSA/MIR10981 MSA_FASTA/MIR10981
extractalign MSA/MIR10982 MSA_FASTA/MIR10982
extractalign MSA/MIR10989 MSA_FASTA/MIR10989
extractalign MSA/MIR10991 MSA_FASTA/MIR10991
extractalign MSA/MIR10993 MSA_FASTA/MIR10993
extractalign MSA/MIR11068 MSA_FASTA/MIR11068
extractalign MSA/MIR11072 MSA_FASTA/MIR11072
extractalign MSA/MIR11077 MSA_FASTA/MIR11077
extractalign MSA/MIR11078 MSA_FASTA/MIR11078
extractalign MSA/MIR11082 MSA_FASTA/MIR11082
extractalign MSA/MIR11083 MSA_FASTA/MIR11083
extractalign MSA/MIR11090 MSA_FASTA/MIR11090
extractalign MSA/MIR11097 MSA_FASTA/MIR11097
extractalign MSA/MIR11103 MSA_FASTA/MIR11103
extractalign MSA/MIR11105 MSA_FASTA/MIR11105
extractalign MSA/MIR11108 MSA_FASTA/MIR11108
extractalign MSA/MIR11135 MSA_FASTA/MIR11135
extractalign MSA/MIR11145 MSA_FASTA/MIR11145
extractalign MSA/MIR11155 MSA_FASTA/MIR11155
extractalign MSA/MIR11288 MSA_FASTA/MIR11288
extractalign MSA/MIR11409 MSA_FASTA/MIR11409
extractalign MSA/MIR11411 MSA_FASTA/MIR11411
extractalign MSA/MIR11420 MSA_FASTA/MIR11420
extractalign MSA/MIR11423 MSA_FASTA/MIR11423
extractalign MSA/MIR11425 MSA_FASTA/MIR11425
extractalign MSA/MIR11429 MSA_FASTA/MIR11429
extractalign MSA/MIR11436 MSA_FASTA/MIR11436
extractalign MSA/MIR11466 MSA_FASTA/MIR11466
extractalign MSA/MIR11523 MSA_FASTA/MIR11523
extractalign MSA/MIR11546 MSA_FASTA/MIR11546
degapseq MSA_FASTA/MIR156 miRNAsIdentified/MIR156
degapseq MSA_FASTA/MIR157 miRNAsIdentified/MIR157
degapseq MSA_FASTA/MIR158 miRNAsIdentified/MIR158
degapseq MSA_FASTA/MIR159 miRNAsIdentified/MIR159
degapseq MSA_FASTA/MIR160 miRNAsIdentified/MIR160
degapseq MSA_FASTA/MIR161 miRNAsIdentified/MIR161
degapseq MSA_FASTA/MIR162 miRNAsIdentified/MIR162
degapseq MSA_FASTA/MIR164 miRNAsIdentified/MIR164
degapseq MSA_FASTA/MIR165 miRNAsIdentified/MIR165
degapseq MSA_FASTA/MIR166 miRNAsIdentified/MIR166
degapseq MSA_FASTA/MIR167 miRNAsIdentified/MIR167
degapseq MSA_FASTA/MIR168 miRNAsIdentified/MIR168
degapseq MSA_FASTA/MIR169 miRNAsIdentified/MIR169
degapseq MSA_FASTA/MIR171 miRNAsIdentified/MIR171
degapseq MSA_FASTA/MIR172 miRNAsIdentified/MIR172
degapseq MSA_FASTA/MIR173 miRNAsIdentified/MIR173
degapseq MSA_FASTA/MIR319 miRNAsIdentified/MIR319
degapseq MSA_FASTA/MIR390 miRNAsIdentified/MIR390
degapseq MSA_FASTA/MIR391 miRNAsIdentified/MIR391
degapseq MSA_FASTA/MIR393 miRNAsIdentified/MIR393
degapseq MSA_FASTA/MIR394 miRNAsIdentified/MIR394
degapseq MSA_FASTA/MIR395 miRNAsIdentified/MIR395
degapseq MSA_FASTA/MIR396 miRNAsIdentified/MIR396
degapseq MSA_FASTA/MIR397 miRNAsIdentified/MIR397
degapseq MSA_FASTA/MIR398 miRNAsIdentified/MIR398
degapseq MSA_FASTA/MIR399 miRNAsIdentified/MIR399
degapseq MSA_FASTA/MIR400 miRNAsIdentified/MIR400
degapseq MSA_FASTA/MIR403 miRNAsIdentified/MIR403
degapseq MSA_FASTA/MIR408 miRNAsIdentified/MIR408
degapseq MSA_FASTA/MIR437 miRNAsIdentified/MIR437
degapseq MSA_FASTA/MIR439 miRNAsIdentified/MIR439
degapseq MSA_FASTA/MIR444 miRNAsIdentified/MIR444
degapseq MSA_FASTA/MIR472 miRNAsIdentified/MIR472
degapseq MSA_FASTA/MIR475 miRNAsIdentified/MIR475
degapseq MSA_FASTA/MIR477 miRNAsIdentified/MIR477
degapseq MSA_FASTA/MIR478 miRNAsIdentified/MIR478
degapseq MSA_FASTA/MIR479 miRNAsIdentified/MIR479
degapseq MSA_FASTA/MIR481 miRNAsIdentified/MIR481
degapseq MSA_FASTA/MIR482 miRNAsIdentified/MIR482
degapseq MSA_FASTA/MIR528 miRNAsIdentified/MIR528
degapseq MSA_FASTA/MIR529 miRNAsIdentified/MIR529
degapseq MSA_FASTA/MIR530 miRNAsIdentified/MIR530
degapseq MSA_FASTA/MIR531 miRNAsIdentified/MIR531
degapseq MSA_FASTA/MIR533 miRNAsIdentified/MIR533
degapseq MSA_FASTA/MIR535 miRNAsIdentified/MIR535
degapseq MSA_FASTA/MIR536 miRNAsIdentified/MIR536
degapseq MSA_FASTA/MIR537 miRNAsIdentified/MIR537
degapseq MSA_FASTA/MIR774 miRNAsIdentified/MIR774
degapseq MSA_FASTA/MIR812 miRNAsIdentified/MIR812
degapseq MSA_FASTA/MIR818 miRNAsIdentified/MIR818
degapseq MSA_FASTA/MIR821 miRNAsIdentified/MIR821
degapseq MSA_FASTA/MIR824 miRNAsIdentified/MIR824
degapseq MSA_FASTA/MIR827 miRNAsIdentified/MIR827
degapseq MSA_FASTA/MIR828 miRNAsIdentified/MIR828
degapseq MSA_FASTA/MIR845 miRNAsIdentified/MIR845
degapseq MSA_FASTA/MIR854 miRNAsIdentified/MIR854
degapseq MSA_FASTA/MIR857 miRNAsIdentified/MIR857
degapseq MSA_FASTA/MIR858 miRNAsIdentified/MIR858
degapseq MSA_FASTA/MIR860 miRNAsIdentified/MIR860
degapseq MSA_FASTA/MIR862 miRNAsIdentified/MIR862
degapseq MSA_FASTA/MIR902 miRNAsIdentified/MIR902
degapseq MSA_FASTA/MIR946 miRNAsIdentified/MIR946
degapseq MSA_FASTA/MIR949 miRNAsIdentified/MIR949
degapseq MSA_FASTA/MIR950 miRNAsIdentified/MIR950
degapseq MSA_FASTA/MIR952 miRNAsIdentified/MIR952
degapseq MSA_FASTA/MIR1023 miRNAsIdentified/MIR1023
degapseq MSA_FASTA/MIR1030 miRNAsIdentified/MIR1030
degapseq MSA_FASTA/MIR1033 miRNAsIdentified/MIR1033
degapseq MSA_FASTA/MIR1063 miRNAsIdentified/MIR1063
degapseq MSA_FASTA/MIR1120 miRNAsIdentified/MIR1120
degapseq MSA_FASTA/MIR1122 miRNAsIdentified/MIR1122
degapseq MSA_FASTA/MIR1219 miRNAsIdentified/MIR1219
degapseq MSA_FASTA/MIR1222 miRNAsIdentified/MIR1222
degapseq MSA_FASTA/MIR1223 miRNAsIdentified/MIR1223
degapseq MSA_FASTA/MIR1311 miRNAsIdentified/MIR1311
degapseq MSA_FASTA/MIR1312 miRNAsIdentified/MIR1312
degapseq MSA_FASTA/MIR1313 miRNAsIdentified/MIR1313
degapseq MSA_FASTA/MIR1428 miRNAsIdentified/MIR1428
degapseq MSA_FASTA/MIR1432 miRNAsIdentified/MIR1432
degapseq MSA_FASTA/MIR1444 miRNAsIdentified/MIR1444
degapseq MSA_FASTA/MIR1446 miRNAsIdentified/MIR1446
degapseq MSA_FASTA/MIR1507 miRNAsIdentified/MIR1507
degapseq MSA_FASTA/MIR1508 miRNAsIdentified/MIR1508
degapseq MSA_FASTA/MIR1509 miRNAsIdentified/MIR1509
degapseq MSA_FASTA/MIR1510 miRNAsIdentified/MIR1510
degapseq MSA_FASTA/MIR1511 miRNAsIdentified/MIR1511
degapseq MSA_FASTA/MIR1515 miRNAsIdentified/MIR1515
degapseq MSA_FASTA/MIR1516 miRNAsIdentified/MIR1516
degapseq MSA_FASTA/MIR1520 miRNAsIdentified/MIR1520
degapseq MSA_FASTA/MIR1846 miRNAsIdentified/MIR1846
degapseq MSA_FASTA/MIR1861 miRNAsIdentified/MIR1861
degapseq MSA_FASTA/MIR1862 miRNAsIdentified/MIR1862
degapseq MSA_FASTA/MIR1863 miRNAsIdentified/MIR1863
degapseq MSA_FASTA/MIR1882 miRNAsIdentified/MIR1882
degapseq MSA_FASTA/MIR1886 miRNAsIdentified/MIR1886
degapseq MSA_FASTA/MIR1919 miRNAsIdentified/MIR1919
degapseq MSA_FASTA/MIR2111 miRNAsIdentified/MIR2111
degapseq MSA_FASTA/MIR2118 miRNAsIdentified/MIR2118
degapseq MSA_FASTA/MIR2275 miRNAsIdentified/MIR2275
degapseq MSA_FASTA/MIR2585 miRNAsIdentified/MIR2585
degapseq MSA_FASTA/MIR2587 miRNAsIdentified/MIR2587
degapseq MSA_FASTA/MIR2590 miRNAsIdentified/MIR2590
degapseq MSA_FASTA/MIR2592 miRNAsIdentified/MIR2592
degapseq MSA_FASTA/MIR2593 miRNAsIdentified/MIR2593
degapseq MSA_FASTA/MIR2600 miRNAsIdentified/MIR2600
degapseq MSA_FASTA/MIR2606 miRNAsIdentified/MIR2606
degapseq MSA_FASTA/MIR2629 miRNAsIdentified/MIR2629
degapseq MSA_FASTA/MIR2630 miRNAsIdentified/MIR2630
degapseq MSA_FASTA/MIR2652 miRNAsIdentified/MIR2652
degapseq MSA_FASTA/MIR2653 miRNAsIdentified/MIR2653
degapseq MSA_FASTA/MIR2655 miRNAsIdentified/MIR2655
degapseq MSA_FASTA/MIR2656 miRNAsIdentified/MIR2656
degapseq MSA_FASTA/MIR2659 miRNAsIdentified/MIR2659
degapseq MSA_FASTA/MIR2670 miRNAsIdentified/MIR2670
degapseq MSA_FASTA/MIR2671 miRNAsIdentified/MIR2671
degapseq MSA_FASTA/MIR2676 miRNAsIdentified/MIR2676
degapseq MSA_FASTA/MIR2680 miRNAsIdentified/MIR2680
degapseq MSA_FASTA/MIR2907 miRNAsIdentified/MIR2907
degapseq MSA_FASTA/MIR2950 miRNAsIdentified/MIR2950
degapseq MSA_FASTA/MIR3454 miRNAsIdentified/MIR3454
degapseq MSA_FASTA/MIR3627 miRNAsIdentified/MIR3627
degapseq MSA_FASTA/MIR3631 miRNAsIdentified/MIR3631
degapseq MSA_FASTA/MIR3693 miRNAsIdentified/MIR3693
degapseq MSA_FASTA/MIR3695 miRNAsIdentified/MIR3695
degapseq MSA_FASTA/MIR3701 miRNAsIdentified/MIR3701
degapseq MSA_FASTA/MIR3710 miRNAsIdentified/MIR3710
degapseq MSA_FASTA/MIR4348 miRNAsIdentified/MIR4348
degapseq MSA_FASTA/MIR4387 miRNAsIdentified/MIR4387
degapseq MSA_FASTA/MIR4414 miRNAsIdentified/MIR4414
degapseq MSA_FASTA/MIR5037 miRNAsIdentified/MIR5037
degapseq MSA_FASTA/MIR5049 miRNAsIdentified/MIR5049
degapseq MSA_FASTA/MIR5062 miRNAsIdentified/MIR5062
degapseq MSA_FASTA/MIR5139 miRNAsIdentified/MIR5139
degapseq MSA_FASTA/MIR5174 miRNAsIdentified/MIR5174
degapseq MSA_FASTA/MIR5181 miRNAsIdentified/MIR5181
degapseq MSA_FASTA/MIR5185 miRNAsIdentified/MIR5185
degapseq MSA_FASTA/MIR5200 miRNAsIdentified/MIR5200
degapseq MSA_FASTA/MIR5205 miRNAsIdentified/MIR5205
degapseq MSA_FASTA/MIR5208 miRNAsIdentified/MIR5208
degapseq MSA_FASTA/MIR5225 miRNAsIdentified/MIR5225
degapseq MSA_FASTA/MIR5236 miRNAsIdentified/MIR5236
degapseq MSA_FASTA/MIR5267 miRNAsIdentified/MIR5267
degapseq MSA_FASTA/MIR5271 miRNAsIdentified/MIR5271
degapseq MSA_FASTA/MIR5272 miRNAsIdentified/MIR5272
degapseq MSA_FASTA/MIR5281 miRNAsIdentified/MIR5281
degapseq MSA_FASTA/MIR5284 miRNAsIdentified/MIR5284
degapseq MSA_FASTA/MIR5287 miRNAsIdentified/MIR5287
degapseq MSA_FASTA/MIR5295 miRNAsIdentified/MIR5295
degapseq MSA_FASTA/MIR5298 miRNAsIdentified/MIR5298
degapseq MSA_FASTA/MIR5303 miRNAsIdentified/MIR5303
degapseq MSA_FASTA/MIR5565 miRNAsIdentified/MIR5565
degapseq MSA_FASTA/MIR5568 miRNAsIdentified/MIR5568
degapseq MSA_FASTA/MIR5635 miRNAsIdentified/MIR5635
degapseq MSA_FASTA/MIR5645 miRNAsIdentified/MIR5645
degapseq MSA_FASTA/MIR5741 miRNAsIdentified/MIR5741
degapseq MSA_FASTA/MIR5780 miRNAsIdentified/MIR5780
degapseq MSA_FASTA/MIR6025 miRNAsIdentified/MIR6025
degapseq MSA_FASTA/MIR6108 miRNAsIdentified/MIR6108
degapseq MSA_FASTA/MIR6135 miRNAsIdentified/MIR6135
degapseq MSA_FASTA/MIR6140 miRNAsIdentified/MIR6140
degapseq MSA_FASTA/MIR6145 miRNAsIdentified/MIR6145
degapseq MSA_FASTA/MIR6151 miRNAsIdentified/MIR6151
degapseq MSA_FASTA/MIR6161 miRNAsIdentified/MIR6161
degapseq MSA_FASTA/MIR6425 miRNAsIdentified/MIR6425
degapseq MSA_FASTA/MIR6440 miRNAsIdentified/MIR6440
degapseq MSA_FASTA/MIR6462 miRNAsIdentified/MIR6462
degapseq MSA_FASTA/MIR7121 miRNAsIdentified/MIR7121
degapseq MSA_FASTA/MIR7122 miRNAsIdentified/MIR7122
degapseq MSA_FASTA/MIR7484 miRNAsIdentified/MIR7484
degapseq MSA_FASTA/MIR7486 miRNAsIdentified/MIR7486
degapseq MSA_FASTA/MIR7492 miRNAsIdentified/MIR7492
degapseq MSA_FASTA/MIR7494 miRNAsIdentified/MIR7494
degapseq MSA_FASTA/MIR7502 miRNAsIdentified/MIR7502
degapseq MSA_FASTA/MIR7504 miRNAsIdentified/MIR7504
degapseq MSA_FASTA/MIR7526 miRNAsIdentified/MIR7526
degapseq MSA_FASTA/MIR7533 miRNAsIdentified/MIR7533
degapseq MSA_FASTA/MIR7696 miRNAsIdentified/MIR7696
degapseq MSA_FASTA/MIR7981 miRNAsIdentified/MIR7981
degapseq MSA_FASTA/MIR7984 miRNAsIdentified/MIR7984
degapseq MSA_FASTA/MIR7993 miRNAsIdentified/MIR7993
degapseq MSA_FASTA/MIR8032 miRNAsIdentified/MIR8032
degapseq MSA_FASTA/MIR8139 miRNAsIdentified/MIR8139
degapseq MSA_FASTA/MIR8167 miRNAsIdentified/MIR8167
degapseq MSA_FASTA/MIR8552 miRNAsIdentified/MIR8552
degapseq MSA_FASTA/MIR8565 miRNAsIdentified/MIR8565
degapseq MSA_FASTA/MIR8623 miRNAsIdentified/MIR8623
degapseq MSA_FASTA/MIR8639 miRNAsIdentified/MIR8639
degapseq MSA_FASTA/MIR8657 miRNAsIdentified/MIR8657
degapseq MSA_FASTA/MIR8743 miRNAsIdentified/MIR8743
degapseq MSA_FASTA/MIR8762 miRNAsIdentified/MIR8762
degapseq MSA_FASTA/MIR8771 miRNAsIdentified/MIR8771
degapseq MSA_FASTA/MIR8776 miRNAsIdentified/MIR8776
degapseq MSA_FASTA/MIR8788 miRNAsIdentified/MIR8788
degapseq MSA_FASTA/MIR9560 miRNAsIdentified/MIR9560
degapseq MSA_FASTA/MIR9674 miRNAsIdentified/MIR9674
degapseq MSA_FASTA/MIR9746 miRNAsIdentified/MIR9746
degapseq MSA_FASTA/MIR10186 miRNAsIdentified/MIR10186
degapseq MSA_FASTA/MIR10193 miRNAsIdentified/MIR10193
degapseq MSA_FASTA/MIR10405 miRNAsIdentified/MIR10405
degapseq MSA_FASTA/MIR10407 miRNAsIdentified/MIR10407
degapseq MSA_FASTA/MIR10424 miRNAsIdentified/MIR10424
degapseq MSA_FASTA/MIR10981 miRNAsIdentified/MIR10981
degapseq MSA_FASTA/MIR10982 miRNAsIdentified/MIR10982
degapseq MSA_FASTA/MIR10989 miRNAsIdentified/MIR10989
degapseq MSA_FASTA/MIR10991 miRNAsIdentified/MIR10991
degapseq MSA_FASTA/MIR10993 miRNAsIdentified/MIR10993
degapseq MSA_FASTA/MIR11068 miRNAsIdentified/MIR11068
degapseq MSA_FASTA/MIR11072 miRNAsIdentified/MIR11072
degapseq MSA_FASTA/MIR11077 miRNAsIdentified/MIR11077
degapseq MSA_FASTA/MIR11078 miRNAsIdentified/MIR11078
degapseq MSA_FASTA/MIR11082 miRNAsIdentified/MIR11082
degapseq MSA_FASTA/MIR11083 miRNAsIdentified/MIR11083
degapseq MSA_FASTA/MIR11090 miRNAsIdentified/MIR11090
degapseq MSA_FASTA/MIR11097 miRNAsIdentified/MIR11097
degapseq MSA_FASTA/MIR11103 miRNAsIdentified/MIR11103
degapseq MSA_FASTA/MIR11105 miRNAsIdentified/MIR11105
degapseq MSA_FASTA/MIR11108 miRNAsIdentified/MIR11108
degapseq MSA_FASTA/MIR11135 miRNAsIdentified/MIR11135
degapseq MSA_FASTA/MIR11145 miRNAsIdentified/MIR11145
degapseq MSA_FASTA/MIR11155 miRNAsIdentified/MIR11155
degapseq MSA_FASTA/MIR11288 miRNAsIdentified/MIR11288
degapseq MSA_FASTA/MIR11409 miRNAsIdentified/MIR11409
degapseq MSA_FASTA/MIR11411 miRNAsIdentified/MIR11411
degapseq MSA_FASTA/MIR11420 miRNAsIdentified/MIR11420
degapseq MSA_FASTA/MIR11423 miRNAsIdentified/MIR11423
degapseq MSA_FASTA/MIR11425 miRNAsIdentified/MIR11425
degapseq MSA_FASTA/MIR11429 miRNAsIdentified/MIR11429
degapseq MSA_FASTA/MIR11436 miRNAsIdentified/MIR11436
degapseq MSA_FASTA/MIR11466 miRNAsIdentified/MIR11466
degapseq MSA_FASTA/MIR11523 miRNAsIdentified/MIR11523
degapseq MSA_FASTA/MIR11546 miRNAsIdentified/MIR11546
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR156 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR156 -redundantoutseq miRNAsIdentified_Redundant/MIR156
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR157 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR157 -redundantoutseq miRNAsIdentified_Redundant/MIR157
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR158 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR158 -redundantoutseq miRNAsIdentified_Redundant/MIR158
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR159 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR159 -redundantoutseq miRNAsIdentified_Redundant/MIR159
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR160 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR160 -redundantoutseq miRNAsIdentified_Redundant/MIR160
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR161 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR161 -redundantoutseq miRNAsIdentified_Redundant/MIR161
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR162 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR162 -redundantoutseq miRNAsIdentified_Redundant/MIR162
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR164 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR164 -redundantoutseq miRNAsIdentified_Redundant/MIR164
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR165 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR165 -redundantoutseq miRNAsIdentified_Redundant/MIR165
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR166 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR166 -redundantoutseq miRNAsIdentified_Redundant/MIR166
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR167 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR167 -redundantoutseq miRNAsIdentified_Redundant/MIR167
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR168 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR168 -redundantoutseq miRNAsIdentified_Redundant/MIR168
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR169 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR169 -redundantoutseq miRNAsIdentified_Redundant/MIR169
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR171 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR171 -redundantoutseq miRNAsIdentified_Redundant/MIR171
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR172 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR172 -redundantoutseq miRNAsIdentified_Redundant/MIR172
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR173 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR173 -redundantoutseq miRNAsIdentified_Redundant/MIR173
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR319 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR319 -redundantoutseq miRNAsIdentified_Redundant/MIR319
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR390 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR390 -redundantoutseq miRNAsIdentified_Redundant/MIR390
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR391 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR391 -redundantoutseq miRNAsIdentified_Redundant/MIR391
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR393 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR393 -redundantoutseq miRNAsIdentified_Redundant/MIR393
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR394 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR394 -redundantoutseq miRNAsIdentified_Redundant/MIR394
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR395 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR395 -redundantoutseq miRNAsIdentified_Redundant/MIR395
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR396 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR396 -redundantoutseq miRNAsIdentified_Redundant/MIR396
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR397 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR397 -redundantoutseq miRNAsIdentified_Redundant/MIR397
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR398 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR398 -redundantoutseq miRNAsIdentified_Redundant/MIR398
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR399 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR399 -redundantoutseq miRNAsIdentified_Redundant/MIR399
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR400 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR400 -redundantoutseq miRNAsIdentified_Redundant/MIR400
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR403 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR403 -redundantoutseq miRNAsIdentified_Redundant/MIR403
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR408 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR408 -redundantoutseq miRNAsIdentified_Redundant/MIR408
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR437 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR437 -redundantoutseq miRNAsIdentified_Redundant/MIR437
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR439 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR439 -redundantoutseq miRNAsIdentified_Redundant/MIR439
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR444 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR444 -redundantoutseq miRNAsIdentified_Redundant/MIR444
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR472 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR472 -redundantoutseq miRNAsIdentified_Redundant/MIR472
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR475 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR475 -redundantoutseq miRNAsIdentified_Redundant/MIR475
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR477 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR477 -redundantoutseq miRNAsIdentified_Redundant/MIR477
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR478 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR478 -redundantoutseq miRNAsIdentified_Redundant/MIR478
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR479 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR479 -redundantoutseq miRNAsIdentified_Redundant/MIR479
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR481 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR481 -redundantoutseq miRNAsIdentified_Redundant/MIR481
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR482 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR482 -redundantoutseq miRNAsIdentified_Redundant/MIR482
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR528 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR528 -redundantoutseq miRNAsIdentified_Redundant/MIR528
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR529 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR529 -redundantoutseq miRNAsIdentified_Redundant/MIR529
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR530 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR530 -redundantoutseq miRNAsIdentified_Redundant/MIR530
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR531 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR531 -redundantoutseq miRNAsIdentified_Redundant/MIR531
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR533 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR533 -redundantoutseq miRNAsIdentified_Redundant/MIR533
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR535 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR535 -redundantoutseq miRNAsIdentified_Redundant/MIR535
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR536 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR536 -redundantoutseq miRNAsIdentified_Redundant/MIR536
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR537 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR537 -redundantoutseq miRNAsIdentified_Redundant/MIR537
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR774 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR774 -redundantoutseq miRNAsIdentified_Redundant/MIR774
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR812 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR812 -redundantoutseq miRNAsIdentified_Redundant/MIR812
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR818 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR818 -redundantoutseq miRNAsIdentified_Redundant/MIR818
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR821 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR821 -redundantoutseq miRNAsIdentified_Redundant/MIR821
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR824 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR824 -redundantoutseq miRNAsIdentified_Redundant/MIR824
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR827 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR827 -redundantoutseq miRNAsIdentified_Redundant/MIR827
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR828 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR828 -redundantoutseq miRNAsIdentified_Redundant/MIR828
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR845 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR845 -redundantoutseq miRNAsIdentified_Redundant/MIR845
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR854 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR854 -redundantoutseq miRNAsIdentified_Redundant/MIR854
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR857 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR857 -redundantoutseq miRNAsIdentified_Redundant/MIR857
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR858 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR858 -redundantoutseq miRNAsIdentified_Redundant/MIR858
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR860 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR860 -redundantoutseq miRNAsIdentified_Redundant/MIR860
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR862 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR862 -redundantoutseq miRNAsIdentified_Redundant/MIR862
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR902 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR902 -redundantoutseq miRNAsIdentified_Redundant/MIR902
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR946 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR946 -redundantoutseq miRNAsIdentified_Redundant/MIR946
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR949 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR949 -redundantoutseq miRNAsIdentified_Redundant/MIR949
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR950 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR950 -redundantoutseq miRNAsIdentified_Redundant/MIR950
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR952 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR952 -redundantoutseq miRNAsIdentified_Redundant/MIR952
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1023 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1023 -redundantoutseq miRNAsIdentified_Redundant/MIR1023
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1030 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1030 -redundantoutseq miRNAsIdentified_Redundant/MIR1030
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1033 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1033 -redundantoutseq miRNAsIdentified_Redundant/MIR1033
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1063 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1063 -redundantoutseq miRNAsIdentified_Redundant/MIR1063
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1120 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1120 -redundantoutseq miRNAsIdentified_Redundant/MIR1120
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1122 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1122 -redundantoutseq miRNAsIdentified_Redundant/MIR1122
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1219 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1219 -redundantoutseq miRNAsIdentified_Redundant/MIR1219
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1222 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1222 -redundantoutseq miRNAsIdentified_Redundant/MIR1222
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1223 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1223 -redundantoutseq miRNAsIdentified_Redundant/MIR1223
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1311 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1311 -redundantoutseq miRNAsIdentified_Redundant/MIR1311
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1312 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1312 -redundantoutseq miRNAsIdentified_Redundant/MIR1312
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1313 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1313 -redundantoutseq miRNAsIdentified_Redundant/MIR1313
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1428 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1428 -redundantoutseq miRNAsIdentified_Redundant/MIR1428
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1432 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1432 -redundantoutseq miRNAsIdentified_Redundant/MIR1432
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1444 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1444 -redundantoutseq miRNAsIdentified_Redundant/MIR1444
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1446 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1446 -redundantoutseq miRNAsIdentified_Redundant/MIR1446
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1507 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1507 -redundantoutseq miRNAsIdentified_Redundant/MIR1507
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1508 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1508 -redundantoutseq miRNAsIdentified_Redundant/MIR1508
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1509 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1509 -redundantoutseq miRNAsIdentified_Redundant/MIR1509
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1510 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1510 -redundantoutseq miRNAsIdentified_Redundant/MIR1510
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1511 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1511 -redundantoutseq miRNAsIdentified_Redundant/MIR1511
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1515 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1515 -redundantoutseq miRNAsIdentified_Redundant/MIR1515
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1516 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1516 -redundantoutseq miRNAsIdentified_Redundant/MIR1516
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1520 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1520 -redundantoutseq miRNAsIdentified_Redundant/MIR1520
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1846 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1846 -redundantoutseq miRNAsIdentified_Redundant/MIR1846
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1861 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1861 -redundantoutseq miRNAsIdentified_Redundant/MIR1861
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1862 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1862 -redundantoutseq miRNAsIdentified_Redundant/MIR1862
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1863 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1863 -redundantoutseq miRNAsIdentified_Redundant/MIR1863
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1882 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1882 -redundantoutseq miRNAsIdentified_Redundant/MIR1882
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1886 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1886 -redundantoutseq miRNAsIdentified_Redundant/MIR1886
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR1919 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR1919 -redundantoutseq miRNAsIdentified_Redundant/MIR1919
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2111 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2111 -redundantoutseq miRNAsIdentified_Redundant/MIR2111
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2118 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2118 -redundantoutseq miRNAsIdentified_Redundant/MIR2118
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2275 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2275 -redundantoutseq miRNAsIdentified_Redundant/MIR2275
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2585 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2585 -redundantoutseq miRNAsIdentified_Redundant/MIR2585
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2587 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2587 -redundantoutseq miRNAsIdentified_Redundant/MIR2587
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2590 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2590 -redundantoutseq miRNAsIdentified_Redundant/MIR2590
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2592 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2592 -redundantoutseq miRNAsIdentified_Redundant/MIR2592
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2593 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2593 -redundantoutseq miRNAsIdentified_Redundant/MIR2593
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2600 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2600 -redundantoutseq miRNAsIdentified_Redundant/MIR2600
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2606 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2606 -redundantoutseq miRNAsIdentified_Redundant/MIR2606
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2629 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2629 -redundantoutseq miRNAsIdentified_Redundant/MIR2629
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2630 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2630 -redundantoutseq miRNAsIdentified_Redundant/MIR2630
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2652 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2652 -redundantoutseq miRNAsIdentified_Redundant/MIR2652
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2653 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2653 -redundantoutseq miRNAsIdentified_Redundant/MIR2653
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2655 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2655 -redundantoutseq miRNAsIdentified_Redundant/MIR2655
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2656 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2656 -redundantoutseq miRNAsIdentified_Redundant/MIR2656
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2659 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2659 -redundantoutseq miRNAsIdentified_Redundant/MIR2659
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2670 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2670 -redundantoutseq miRNAsIdentified_Redundant/MIR2670
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2671 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2671 -redundantoutseq miRNAsIdentified_Redundant/MIR2671
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2676 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2676 -redundantoutseq miRNAsIdentified_Redundant/MIR2676
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2680 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2680 -redundantoutseq miRNAsIdentified_Redundant/MIR2680
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2907 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2907 -redundantoutseq miRNAsIdentified_Redundant/MIR2907
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR2950 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR2950 -redundantoutseq miRNAsIdentified_Redundant/MIR2950
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR3454 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR3454 -redundantoutseq miRNAsIdentified_Redundant/MIR3454
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR3627 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR3627 -redundantoutseq miRNAsIdentified_Redundant/MIR3627
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR3631 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR3631 -redundantoutseq miRNAsIdentified_Redundant/MIR3631
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR3693 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR3693 -redundantoutseq miRNAsIdentified_Redundant/MIR3693
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR3695 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR3695 -redundantoutseq miRNAsIdentified_Redundant/MIR3695
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR3701 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR3701 -redundantoutseq miRNAsIdentified_Redundant/MIR3701
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR3710 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR3710 -redundantoutseq miRNAsIdentified_Redundant/MIR3710
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR4348 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR4348 -redundantoutseq miRNAsIdentified_Redundant/MIR4348
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR4387 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR4387 -redundantoutseq miRNAsIdentified_Redundant/MIR4387
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR4414 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR4414 -redundantoutseq miRNAsIdentified_Redundant/MIR4414
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5037 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5037 -redundantoutseq miRNAsIdentified_Redundant/MIR5037
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5049 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5049 -redundantoutseq miRNAsIdentified_Redundant/MIR5049
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5062 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5062 -redundantoutseq miRNAsIdentified_Redundant/MIR5062
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5139 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5139 -redundantoutseq miRNAsIdentified_Redundant/MIR5139
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5174 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5174 -redundantoutseq miRNAsIdentified_Redundant/MIR5174
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5181 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5181 -redundantoutseq miRNAsIdentified_Redundant/MIR5181
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5185 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5185 -redundantoutseq miRNAsIdentified_Redundant/MIR5185
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5200 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5200 -redundantoutseq miRNAsIdentified_Redundant/MIR5200
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5205 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5205 -redundantoutseq miRNAsIdentified_Redundant/MIR5205
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5208 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5208 -redundantoutseq miRNAsIdentified_Redundant/MIR5208
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5225 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5225 -redundantoutseq miRNAsIdentified_Redundant/MIR5225
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5236 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5236 -redundantoutseq miRNAsIdentified_Redundant/MIR5236
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5267 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5267 -redundantoutseq miRNAsIdentified_Redundant/MIR5267
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5271 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5271 -redundantoutseq miRNAsIdentified_Redundant/MIR5271
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5272 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5272 -redundantoutseq miRNAsIdentified_Redundant/MIR5272
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5281 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5281 -redundantoutseq miRNAsIdentified_Redundant/MIR5281
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5284 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5284 -redundantoutseq miRNAsIdentified_Redundant/MIR5284
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5287 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5287 -redundantoutseq miRNAsIdentified_Redundant/MIR5287
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5295 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5295 -redundantoutseq miRNAsIdentified_Redundant/MIR5295
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5298 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5298 -redundantoutseq miRNAsIdentified_Redundant/MIR5298
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5303 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5303 -redundantoutseq miRNAsIdentified_Redundant/MIR5303
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5565 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5565 -redundantoutseq miRNAsIdentified_Redundant/MIR5565
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5568 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5568 -redundantoutseq miRNAsIdentified_Redundant/MIR5568
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5635 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5635 -redundantoutseq miRNAsIdentified_Redundant/MIR5635
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5645 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5645 -redundantoutseq miRNAsIdentified_Redundant/MIR5645
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5741 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5741 -redundantoutseq miRNAsIdentified_Redundant/MIR5741
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR5780 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR5780 -redundantoutseq miRNAsIdentified_Redundant/MIR5780
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR6025 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR6025 -redundantoutseq miRNAsIdentified_Redundant/MIR6025
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR6108 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR6108 -redundantoutseq miRNAsIdentified_Redundant/MIR6108
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR6135 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR6135 -redundantoutseq miRNAsIdentified_Redundant/MIR6135
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR6140 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR6140 -redundantoutseq miRNAsIdentified_Redundant/MIR6140
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR6145 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR6145 -redundantoutseq miRNAsIdentified_Redundant/MIR6145
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR6151 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR6151 -redundantoutseq miRNAsIdentified_Redundant/MIR6151
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR6161 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR6161 -redundantoutseq miRNAsIdentified_Redundant/MIR6161
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR6425 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR6425 -redundantoutseq miRNAsIdentified_Redundant/MIR6425
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR6440 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR6440 -redundantoutseq miRNAsIdentified_Redundant/MIR6440
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR6462 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR6462 -redundantoutseq miRNAsIdentified_Redundant/MIR6462
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7121 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7121 -redundantoutseq miRNAsIdentified_Redundant/MIR7121
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7122 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7122 -redundantoutseq miRNAsIdentified_Redundant/MIR7122
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7484 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7484 -redundantoutseq miRNAsIdentified_Redundant/MIR7484
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7486 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7486 -redundantoutseq miRNAsIdentified_Redundant/MIR7486
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7492 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7492 -redundantoutseq miRNAsIdentified_Redundant/MIR7492
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7494 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7494 -redundantoutseq miRNAsIdentified_Redundant/MIR7494
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7502 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7502 -redundantoutseq miRNAsIdentified_Redundant/MIR7502
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7504 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7504 -redundantoutseq miRNAsIdentified_Redundant/MIR7504
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7526 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7526 -redundantoutseq miRNAsIdentified_Redundant/MIR7526
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7533 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7533 -redundantoutseq miRNAsIdentified_Redundant/MIR7533
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7696 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7696 -redundantoutseq miRNAsIdentified_Redundant/MIR7696
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7981 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7981 -redundantoutseq miRNAsIdentified_Redundant/MIR7981
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7984 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7984 -redundantoutseq miRNAsIdentified_Redundant/MIR7984
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR7993 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR7993 -redundantoutseq miRNAsIdentified_Redundant/MIR7993
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR8032 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR8032 -redundantoutseq miRNAsIdentified_Redundant/MIR8032
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR8139 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR8139 -redundantoutseq miRNAsIdentified_Redundant/MIR8139
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR8167 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR8167 -redundantoutseq miRNAsIdentified_Redundant/MIR8167
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR8552 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR8552 -redundantoutseq miRNAsIdentified_Redundant/MIR8552
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR8565 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR8565 -redundantoutseq miRNAsIdentified_Redundant/MIR8565
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR8623 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR8623 -redundantoutseq miRNAsIdentified_Redundant/MIR8623
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR8639 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR8639 -redundantoutseq miRNAsIdentified_Redundant/MIR8639
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR8657 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR8657 -redundantoutseq miRNAsIdentified_Redundant/MIR8657
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR8743 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR8743 -redundantoutseq miRNAsIdentified_Redundant/MIR8743
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR8762 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR8762 -redundantoutseq miRNAsIdentified_Redundant/MIR8762
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR8771 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR8771 -redundantoutseq miRNAsIdentified_Redundant/MIR8771
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR8776 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR8776 -redundantoutseq miRNAsIdentified_Redundant/MIR8776
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR8788 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR8788 -redundantoutseq miRNAsIdentified_Redundant/MIR8788
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR9560 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR9560 -redundantoutseq miRNAsIdentified_Redundant/MIR9560
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR9674 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR9674 -redundantoutseq miRNAsIdentified_Redundant/MIR9674
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR9746 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR9746 -redundantoutseq miRNAsIdentified_Redundant/MIR9746
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR10186 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR10186 -redundantoutseq miRNAsIdentified_Redundant/MIR10186
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR10193 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR10193 -redundantoutseq miRNAsIdentified_Redundant/MIR10193
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR10405 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR10405 -redundantoutseq miRNAsIdentified_Redundant/MIR10405
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR10407 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR10407 -redundantoutseq miRNAsIdentified_Redundant/MIR10407
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR10424 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR10424 -redundantoutseq miRNAsIdentified_Redundant/MIR10424
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR10981 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR10981 -redundantoutseq miRNAsIdentified_Redundant/MIR10981
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR10982 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR10982 -redundantoutseq miRNAsIdentified_Redundant/MIR10982
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR10989 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR10989 -redundantoutseq miRNAsIdentified_Redundant/MIR10989
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR10991 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR10991 -redundantoutseq miRNAsIdentified_Redundant/MIR10991
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR10993 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR10993 -redundantoutseq miRNAsIdentified_Redundant/MIR10993
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11068 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11068 -redundantoutseq miRNAsIdentified_Redundant/MIR11068
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11072 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11072 -redundantoutseq miRNAsIdentified_Redundant/MIR11072
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11077 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11077 -redundantoutseq miRNAsIdentified_Redundant/MIR11077
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11078 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11078 -redundantoutseq miRNAsIdentified_Redundant/MIR11078
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11082 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11082 -redundantoutseq miRNAsIdentified_Redundant/MIR11082
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11083 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11083 -redundantoutseq miRNAsIdentified_Redundant/MIR11083
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11090 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11090 -redundantoutseq miRNAsIdentified_Redundant/MIR11090
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11097 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11097 -redundantoutseq miRNAsIdentified_Redundant/MIR11097
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11103 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11103 -redundantoutseq miRNAsIdentified_Redundant/MIR11103
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11105 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11105 -redundantoutseq miRNAsIdentified_Redundant/MIR11105
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11108 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11108 -redundantoutseq miRNAsIdentified_Redundant/MIR11108
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11135 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11135 -redundantoutseq miRNAsIdentified_Redundant/MIR11135
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11145 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11145 -redundantoutseq miRNAsIdentified_Redundant/MIR11145
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11155 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11155 -redundantoutseq miRNAsIdentified_Redundant/MIR11155
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11288 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11288 -redundantoutseq miRNAsIdentified_Redundant/MIR11288
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11409 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11409 -redundantoutseq miRNAsIdentified_Redundant/MIR11409
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11411 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11411 -redundantoutseq miRNAsIdentified_Redundant/MIR11411
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11420 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11420 -redundantoutseq miRNAsIdentified_Redundant/MIR11420
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11423 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11423 -redundantoutseq miRNAsIdentified_Redundant/MIR11423
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11425 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11425 -redundantoutseq miRNAsIdentified_Redundant/MIR11425
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11429 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11429 -redundantoutseq miRNAsIdentified_Redundant/MIR11429
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11436 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11436 -redundantoutseq miRNAsIdentified_Redundant/MIR11436
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11466 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11466 -redundantoutseq miRNAsIdentified_Redundant/MIR11466
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11523 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11523 -redundantoutseq miRNAsIdentified_Redundant/MIR11523
skipredundant -feature toggle -sequences  miRNAsIdentified/MIR11546 [-datafile  matrixf] -mode 1 -threshold 80 -minthreshold 30 -maxthreshold 90 -gapopen  10 -gapextend 5 -outseq  miRNAsIdentified_NonRedundant/MIR11546 -redundantoutseq miRNAsIdentified_Redundant/MIR11546
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR156 cmbuild_cmcalibrate/MIR156.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR157 cmbuild_cmcalibrate/MIR157.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR158 cmbuild_cmcalibrate/MIR158.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR159 cmbuild_cmcalibrate/MIR159.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR160 cmbuild_cmcalibrate/MIR160.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR161 cmbuild_cmcalibrate/MIR161.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR162 cmbuild_cmcalibrate/MIR162.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR164 cmbuild_cmcalibrate/MIR164.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR165 cmbuild_cmcalibrate/MIR165.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR166 cmbuild_cmcalibrate/MIR166.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR167 cmbuild_cmcalibrate/MIR167.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR168 cmbuild_cmcalibrate/MIR168.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR169 cmbuild_cmcalibrate/MIR169.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR171 cmbuild_cmcalibrate/MIR171.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR172 cmbuild_cmcalibrate/MIR172.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR173 cmbuild_cmcalibrate/MIR173.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR319 cmbuild_cmcalibrate/MIR319.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR390 cmbuild_cmcalibrate/MIR390.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR391 cmbuild_cmcalibrate/MIR391.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR393 cmbuild_cmcalibrate/MIR393.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR394 cmbuild_cmcalibrate/MIR394.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR395 cmbuild_cmcalibrate/MIR395.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR396 cmbuild_cmcalibrate/MIR396.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR397 cmbuild_cmcalibrate/MIR397.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR398 cmbuild_cmcalibrate/MIR398.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR399 cmbuild_cmcalibrate/MIR399.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR400 cmbuild_cmcalibrate/MIR400.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR403 cmbuild_cmcalibrate/MIR403.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR408 cmbuild_cmcalibrate/MIR408.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR437 cmbuild_cmcalibrate/MIR437.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR439 cmbuild_cmcalibrate/MIR439.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR444 cmbuild_cmcalibrate/MIR444.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR472 cmbuild_cmcalibrate/MIR472.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR475 cmbuild_cmcalibrate/MIR475.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR477 cmbuild_cmcalibrate/MIR477.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR478 cmbuild_cmcalibrate/MIR478.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR479 cmbuild_cmcalibrate/MIR479.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR481 cmbuild_cmcalibrate/MIR481.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR482 cmbuild_cmcalibrate/MIR482.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR528 cmbuild_cmcalibrate/MIR528.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR529 cmbuild_cmcalibrate/MIR529.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR530 cmbuild_cmcalibrate/MIR530.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR531 cmbuild_cmcalibrate/MIR531.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR533 cmbuild_cmcalibrate/MIR533.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR535 cmbuild_cmcalibrate/MIR535.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR536 cmbuild_cmcalibrate/MIR536.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR537 cmbuild_cmcalibrate/MIR537.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR774 cmbuild_cmcalibrate/MIR774.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR812 cmbuild_cmcalibrate/MIR812.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR818 cmbuild_cmcalibrate/MIR818.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR821 cmbuild_cmcalibrate/MIR821.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR824 cmbuild_cmcalibrate/MIR824.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR827 cmbuild_cmcalibrate/MIR827.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR828 cmbuild_cmcalibrate/MIR828.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR845 cmbuild_cmcalibrate/MIR845.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR854 cmbuild_cmcalibrate/MIR854.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR857 cmbuild_cmcalibrate/MIR857.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR858 cmbuild_cmcalibrate/MIR858.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR860 cmbuild_cmcalibrate/MIR860.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR862 cmbuild_cmcalibrate/MIR862.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR902 cmbuild_cmcalibrate/MIR902.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR946 cmbuild_cmcalibrate/MIR946.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR949 cmbuild_cmcalibrate/MIR949.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR950 cmbuild_cmcalibrate/MIR950.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR952 cmbuild_cmcalibrate/MIR952.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1023 cmbuild_cmcalibrate/MIR1023.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1030 cmbuild_cmcalibrate/MIR1030.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1033 cmbuild_cmcalibrate/MIR1033.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1063 cmbuild_cmcalibrate/MIR1063.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1120 cmbuild_cmcalibrate/MIR1120.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1122 cmbuild_cmcalibrate/MIR1122.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1219 cmbuild_cmcalibrate/MIR1219.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1222 cmbuild_cmcalibrate/MIR1222.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1223 cmbuild_cmcalibrate/MIR1223.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1311 cmbuild_cmcalibrate/MIR1311.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1312 cmbuild_cmcalibrate/MIR1312.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1313 cmbuild_cmcalibrate/MIR1313.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1428 cmbuild_cmcalibrate/MIR1428.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1432 cmbuild_cmcalibrate/MIR1432.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1444 cmbuild_cmcalibrate/MIR1444.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1446 cmbuild_cmcalibrate/MIR1446.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1507 cmbuild_cmcalibrate/MIR1507.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1508 cmbuild_cmcalibrate/MIR1508.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1509 cmbuild_cmcalibrate/MIR1509.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1510 cmbuild_cmcalibrate/MIR1510.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1511 cmbuild_cmcalibrate/MIR1511.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1515 cmbuild_cmcalibrate/MIR1515.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1516 cmbuild_cmcalibrate/MIR1516.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1520 cmbuild_cmcalibrate/MIR1520.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1846 cmbuild_cmcalibrate/MIR1846.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1861 cmbuild_cmcalibrate/MIR1861.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1862 cmbuild_cmcalibrate/MIR1862.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1863 cmbuild_cmcalibrate/MIR1863.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1882 cmbuild_cmcalibrate/MIR1882.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1886 cmbuild_cmcalibrate/MIR1886.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR1919 cmbuild_cmcalibrate/MIR1919.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2111 cmbuild_cmcalibrate/MIR2111.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2118 cmbuild_cmcalibrate/MIR2118.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2275 cmbuild_cmcalibrate/MIR2275.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2585 cmbuild_cmcalibrate/MIR2585.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2587 cmbuild_cmcalibrate/MIR2587.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2590 cmbuild_cmcalibrate/MIR2590.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2592 cmbuild_cmcalibrate/MIR2592.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2593 cmbuild_cmcalibrate/MIR2593.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2600 cmbuild_cmcalibrate/MIR2600.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2606 cmbuild_cmcalibrate/MIR2606.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2629 cmbuild_cmcalibrate/MIR2629.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2630 cmbuild_cmcalibrate/MIR2630.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2652 cmbuild_cmcalibrate/MIR2652.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2653 cmbuild_cmcalibrate/MIR2653.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2655 cmbuild_cmcalibrate/MIR2655.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2656 cmbuild_cmcalibrate/MIR2656.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2659 cmbuild_cmcalibrate/MIR2659.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2670 cmbuild_cmcalibrate/MIR2670.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2671 cmbuild_cmcalibrate/MIR2671.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2676 cmbuild_cmcalibrate/MIR2676.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2680 cmbuild_cmcalibrate/MIR2680.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2907 cmbuild_cmcalibrate/MIR2907.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR2950 cmbuild_cmcalibrate/MIR2950.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR3454 cmbuild_cmcalibrate/MIR3454.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR3627 cmbuild_cmcalibrate/MIR3627.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR3631 cmbuild_cmcalibrate/MIR3631.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR3693 cmbuild_cmcalibrate/MIR3693.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR3695 cmbuild_cmcalibrate/MIR3695.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR3701 cmbuild_cmcalibrate/MIR3701.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR3710 cmbuild_cmcalibrate/MIR3710.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR4348 cmbuild_cmcalibrate/MIR4348.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR4387 cmbuild_cmcalibrate/MIR4387.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR4414 cmbuild_cmcalibrate/MIR4414.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5037 cmbuild_cmcalibrate/MIR5037.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5049 cmbuild_cmcalibrate/MIR5049.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5062 cmbuild_cmcalibrate/MIR5062.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5139 cmbuild_cmcalibrate/MIR5139.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5174 cmbuild_cmcalibrate/MIR5174.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5181 cmbuild_cmcalibrate/MIR5181.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5185 cmbuild_cmcalibrate/MIR5185.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5200 cmbuild_cmcalibrate/MIR5200.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5205 cmbuild_cmcalibrate/MIR5205.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5208 cmbuild_cmcalibrate/MIR5208.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5225 cmbuild_cmcalibrate/MIR5225.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5236 cmbuild_cmcalibrate/MIR5236.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5267 cmbuild_cmcalibrate/MIR5267.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5271 cmbuild_cmcalibrate/MIR5271.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5272 cmbuild_cmcalibrate/MIR5272.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5281 cmbuild_cmcalibrate/MIR5281.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5284 cmbuild_cmcalibrate/MIR5284.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5287 cmbuild_cmcalibrate/MIR5287.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5295 cmbuild_cmcalibrate/MIR5295.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5298 cmbuild_cmcalibrate/MIR5298.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5303 cmbuild_cmcalibrate/MIR5303.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5565 cmbuild_cmcalibrate/MIR5565.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5568 cmbuild_cmcalibrate/MIR5568.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5635 cmbuild_cmcalibrate/MIR5635.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5645 cmbuild_cmcalibrate/MIR5645.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5741 cmbuild_cmcalibrate/MIR5741.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR5780 cmbuild_cmcalibrate/MIR5780.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR6025 cmbuild_cmcalibrate/MIR6025.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR6108 cmbuild_cmcalibrate/MIR6108.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR6135 cmbuild_cmcalibrate/MIR6135.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR6140 cmbuild_cmcalibrate/MIR6140.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR6145 cmbuild_cmcalibrate/MIR6145.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR6151 cmbuild_cmcalibrate/MIR6151.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR6161 cmbuild_cmcalibrate/MIR6161.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR6425 cmbuild_cmcalibrate/MIR6425.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR6440 cmbuild_cmcalibrate/MIR6440.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR6462 cmbuild_cmcalibrate/MIR6462.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7121 cmbuild_cmcalibrate/MIR7121.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7122 cmbuild_cmcalibrate/MIR7122.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7484 cmbuild_cmcalibrate/MIR7484.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7486 cmbuild_cmcalibrate/MIR7486.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7492 cmbuild_cmcalibrate/MIR7492.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7494 cmbuild_cmcalibrate/MIR7494.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7502 cmbuild_cmcalibrate/MIR7502.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7504 cmbuild_cmcalibrate/MIR7504.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7526 cmbuild_cmcalibrate/MIR7526.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7533 cmbuild_cmcalibrate/MIR7533.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7696 cmbuild_cmcalibrate/MIR7696.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7981 cmbuild_cmcalibrate/MIR7981.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7984 cmbuild_cmcalibrate/MIR7984.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR7993 cmbuild_cmcalibrate/MIR7993.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR8032 cmbuild_cmcalibrate/MIR8032.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR8139 cmbuild_cmcalibrate/MIR8139.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR8167 cmbuild_cmcalibrate/MIR8167.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR8552 cmbuild_cmcalibrate/MIR8552.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR8565 cmbuild_cmcalibrate/MIR8565.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR8623 cmbuild_cmcalibrate/MIR8623.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR8639 cmbuild_cmcalibrate/MIR8639.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR8657 cmbuild_cmcalibrate/MIR8657.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR8743 cmbuild_cmcalibrate/MIR8743.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR8762 cmbuild_cmcalibrate/MIR8762.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR8771 cmbuild_cmcalibrate/MIR8771.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR8776 cmbuild_cmcalibrate/MIR8776.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR8788 cmbuild_cmcalibrate/MIR8788.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR9560 cmbuild_cmcalibrate/MIR9560.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR9674 cmbuild_cmcalibrate/MIR9674.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR9746 cmbuild_cmcalibrate/MIR9746.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR10186 cmbuild_cmcalibrate/MIR10186.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR10193 cmbuild_cmcalibrate/MIR10193.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR10405 cmbuild_cmcalibrate/MIR10405.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR10407 cmbuild_cmcalibrate/MIR10407.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR10424 cmbuild_cmcalibrate/MIR10424.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR10981 cmbuild_cmcalibrate/MIR10981.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR10982 cmbuild_cmcalibrate/MIR10982.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR10989 cmbuild_cmcalibrate/MIR10989.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR10991 cmbuild_cmcalibrate/MIR10991.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR10993 cmbuild_cmcalibrate/MIR10993.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11068 cmbuild_cmcalibrate/MIR11068.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11072 cmbuild_cmcalibrate/MIR11072.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11077 cmbuild_cmcalibrate/MIR11077.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11078 cmbuild_cmcalibrate/MIR11078.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11082 cmbuild_cmcalibrate/MIR11082.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11083 cmbuild_cmcalibrate/MIR11083.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11090 cmbuild_cmcalibrate/MIR11090.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11097 cmbuild_cmcalibrate/MIR11097.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11103 cmbuild_cmcalibrate/MIR11103.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11105 cmbuild_cmcalibrate/MIR11105.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11108 cmbuild_cmcalibrate/MIR11108.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11135 cmbuild_cmcalibrate/MIR11135.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11145 cmbuild_cmcalibrate/MIR11145.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11155 cmbuild_cmcalibrate/MIR11155.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11288 cmbuild_cmcalibrate/MIR11288.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11409 cmbuild_cmcalibrate/MIR11409.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11411 cmbuild_cmcalibrate/MIR11411.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11420 cmbuild_cmcalibrate/MIR11420.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11423 cmbuild_cmcalibrate/MIR11423.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11425 cmbuild_cmcalibrate/MIR11425.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11429 cmbuild_cmcalibrate/MIR11429.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11436 cmbuild_cmcalibrate/MIR11436.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11466 cmbuild_cmcalibrate/MIR11466.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11523 cmbuild_cmcalibrate/MIR11523.cm genome
cmsearch -E 0.05 --tblout miRNAsIdentified_Tabular/MIR11546 cmbuild_cmcalibrate/MIR11546.cm genome







