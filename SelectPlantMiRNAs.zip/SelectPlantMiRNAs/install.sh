#install infernal ubuntu
sudo apt-get update -y
sudo apt-get install -y infernal
